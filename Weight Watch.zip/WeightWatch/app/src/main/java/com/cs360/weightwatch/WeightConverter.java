package com.cs360.weightwatch;

// WeightConverterUtil.java
public class WeightConverter {
    public static float convertToKg(float weightInPounds) {
        return weightInPounds / 2.20462f;
    }

    public static float convertToPounds(float weightInKg) {
        return weightInKg * 2.20462f;
    }
}